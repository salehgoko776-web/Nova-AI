// بعد نشر السيرفر على Render غيّر الرابط التالي إلى رابط Render الخاص بك.
const NOVA_API_URL = "https://YOUR-NOVA-SERVER.onrender.com";

export async function sendNovaMessage(message, history = []) {
  const response = await fetch(`${NOVA_API_URL}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history })
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Nova server error");
  return data.reply;
}
