import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.get("/", (_req, res) => {
  res.json({ ok: true, app: "Nova AI", status: "online" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "message is required" });
    }
    if (!GEMINI_API_KEY) {
      return res.status(500).json({ error: "GEMINI_API_KEY is not configured" });
    }

    const contents = [
      ...history.filter(x => x && x.role && x.text).map(x => ({
        role: x.role === "assistant" ? "model" : "user",
        parts: [{ text: String(x.text) }]
      })),
      { role: "user", parts: [{ text: message }] }
    ];

    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{
            text: "You are Nova, a friendly personal AI companion. Reply naturally and warmly. When the user speaks Arabic, reply in Arabic unless asked otherwise."
          }]
        },
        contents,
        generationConfig: { temperature: 0.8 }
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "Gemini request failed"
      });
    }

    const reply = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "").join("") || "ما قدرت أطلع رد الآن.";

    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
});

app.listen(PORT, () => console.log(`Nova server running on port ${PORT}`));
