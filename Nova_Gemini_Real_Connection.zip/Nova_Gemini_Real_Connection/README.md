# Nova — Gemini Real AI Connection

هذا المشروع يربط واجهة Nova بسيرفر آمن ثم بـ Gemini.

Render:
- Root Directory: server
- Build Command: npm install
- Start Command: npm start

Environment Variables:
- GEMINI_API_KEY = مفتاح Gemini الجديد
- GEMINI_MODEL = gemini-2.5-flash

لا تضع مفتاح Gemini داخل HTML أو JavaScript.
